"use client";

import { useEffect, useRef, useState } from "react";
import type { MouseEvent, CSSProperties } from "react";
import PlatformLayers from "./PlatformLayers";

const whyHighlights = [
  {
    num: "01",
    tag: "Auto-Triage",
    title: "Automate repetitive routing",
    description: "Automatically classify, assign, and approve requests across IT, HR, and operations without manual inbox triage.",
    depth: "18px",
    driftX: "-8px",
    tilt: "2.4deg",
    delay: "0s",
  },
  {
    num: "02",
    tag: "Rapid Fix",
    title: "Resolve incidents faster",
    description: "Guided workflows, SLA alerts, and root-cause context help teams fix issues early and prevent repeat outages.",
    depth: "58px",
    driftX: "10px",
    tilt: "-2.8deg",
    delay: ".11s",
  },
  {
    num: "03",
    tag: "Live Metrics",
    title: "Real-time SLA visibility",
    description: "Live dashboards and Performance Analytics track backlog, resolution times, and service health in one shared view.",
    depth: "24px",
    driftX: "-6px",
    tilt: "2deg",
    delay: ".22s",
  },
  {
    num: "04",
    tag: "Unified Sync",
    title: "One connected workspace",
    description: "Unite ServiceNow modules with email, identity, monitoring, and HR tools so teams act on the same live data.",
    depth: "64px",
    driftX: "8px",
    tilt: "-2.4deg",
    delay: ".33s",
  },
] as const;

export default function HomeExperience() {
  const [whyReveal, setWhyReveal] = useState<"idle" | "armed" | "visible">("idle");
  const [activeWhyIdx, setActiveWhyIdx] = useState(0);
  const [whyPaused, setWhyPaused] = useState(false);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);
  const whySectionRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const section = whySectionRef.current;
    if (!section) return;

    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    setPrefersReducedMotion(reducedMotion);
    if (reducedMotion) {
      setWhyReveal("visible");
      section.style.setProperty("--why-p", "0");
      return;
    }

    const computeTargetProgress = () => {
      const rect = section.getBoundingClientRect();
      const viewportHeight = window.innerHeight || 1;
      const totalSpan = (viewportHeight + rect.height) * 0.5;
      const centerOffset = rect.top + rect.height * 0.5 - viewportHeight * 0.5;
      return totalSpan > 0 ? Math.max(-1, Math.min(1, centerOffset / totalSpan)) : 0;
    };

    const rectOnMount = section.getBoundingClientRect();
    const alreadyInView = rectOnMount.top < window.innerHeight * 0.78 && rectOnMount.bottom > 80;
    setWhyReveal(alreadyInView ? "visible" : "armed");

    let observer: IntersectionObserver | undefined;
    if (!alreadyInView && "IntersectionObserver" in window) {
      observer = new IntersectionObserver(
        (entries) => {
          if (entries.some((entry) => entry.isIntersecting)) {
            setWhyReveal("visible");
            observer?.disconnect();
          }
        },
        { threshold: 0.22, rootMargin: "0px 0px -60px 0px" }
      );
      observer.observe(section);
    }

    let currentP = computeTargetProgress();
    let targetP = currentP;
    let frame = 0;
    section.style.setProperty("--why-p", currentP.toFixed(4));

    const tick = () => {
      const diff = targetP - currentP;
      if (Math.abs(diff) < 0.0008) {
        currentP = targetP;
        section.style.setProperty("--why-p", currentP.toFixed(4));
        frame = 0;
        return;
      }
      currentP += diff * 0.14;
      section.style.setProperty("--why-p", currentP.toFixed(4));
      frame = window.requestAnimationFrame(tick);
    };

    const onScrollOrResize = () => {
      const rect = section.getBoundingClientRect();
      const viewportHeight = window.innerHeight || 1;
      targetP = computeTargetProgress();
      if (rect.top < viewportHeight * 0.8 && rect.bottom > 60) {
        setWhyReveal("visible");
        observer?.disconnect();
      }
      if (!frame) frame = window.requestAnimationFrame(tick);
    };

    window.addEventListener("scroll", onScrollOrResize, { passive: true });
    window.addEventListener("resize", onScrollOrResize, { passive: true });

    return () => {
      observer?.disconnect();
      window.removeEventListener("scroll", onScrollOrResize);
      window.removeEventListener("resize", onScrollOrResize);
      if (frame) window.cancelAnimationFrame(frame);
    };
  }, []);

  useEffect(() => {
    if (whyReveal !== "visible" || whyPaused || prefersReducedMotion) return;
    const timer = window.setInterval(() => {
      setActiveWhyIdx((prev) => (prev + 1) % whyHighlights.length);
    }, 2600);
    return () => window.clearInterval(timer);
  }, [whyReveal, whyPaused, prefersReducedMotion]);

  const handleWhyPointerMove = (event: MouseEvent<HTMLElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const x = (((event.clientX - rect.left) / rect.width) * 100).toFixed(1);
    const y = (((event.clientY - rect.top) / rect.height) * 100).toFixed(1);
    event.currentTarget.style.setProperty("--mx", `${x}%`);
    event.currentTarget.style.setProperty("--my", `${y}%`);
  };

  return (
    <>
      <section data-why-reveal={whyReveal} id="why-us" ref={whySectionRef}><div className="w">
<div className="why-intro"><div className="why-intro-inner">
<p className="kick">Why NowITSystems</p>
<h2>Less friction.<br />Better workflows.</h2>
<p className="lead">We build ServiceNow workflows around how your teams actually work — cutting manual handoffs, speeding up resolution, and keeping every request visible.</p>
<div aria-label="Workflow highlights" className="why-steps" onMouseEnter={() => setWhyPaused(true)} onMouseLeave={() => setWhyPaused(false)}>
{whyHighlights.map((item, idx) => (
  <button
    aria-pressed={idx === activeWhyIdx}
    className={`why-step${idx === activeWhyIdx ? " is-active" : ""}`}
    key={item.num}
    onClick={() => setActiveWhyIdx(idx)}
    onFocus={() => { setWhyPaused(true); setActiveWhyIdx(idx); }}
    onBlur={() => setWhyPaused(false)}
    type="button"
  >
    <b>{item.num}</b><span>{item.tag}</span>
  </button>
))}
</div>
</div></div>
<div className="bn" id="bn">
{whyHighlights.map((item, idx) => {
  const isActive = idx === activeWhyIdx;
  return (
    <div
      className="why-card-slot"
      key={item.num}
      style={{
        "--p-depth": item.depth,
        "--p-x": item.driftX,
        "--p-tilt": item.tilt,
        "--dl": item.delay,
      } as CSSProperties}
    >
      <article
        className={`why-card${isActive ? " is-active" : ""}${isActive && whyPaused ? " is-paused" : ""}`}
        onMouseEnter={() => { setWhyPaused(true); setActiveWhyIdx(idx); }}
        onMouseLeave={() => setWhyPaused(false)}
        onMouseMove={handleWhyPointerMove}
      >
        <div className="why-card-head">
          <span className="why-num">{item.num}</span>
          <em className="why-tag"><i aria-hidden="true"></i>{item.tag}</em>
        </div>
        <h3>{item.title}</h3>
        <p>{item.description}</p>
        <div aria-hidden="true" className="why-card-bar"></div>
      </article>
    </div>
  );
})}
</div>
</div></section><section id="scatter" style={{ "paddingTop": "0" }}><div className="w">
<div className="dh rv"><p className="kick">Before & after</p><h2>From scattered requests to one clear queue</h2><p className="lead">Email threads, chats, spreadsheets and phone calls all land in one place, get routed automatically and come out the other side resolved.</p></div>
<div className="ba rv">
<svg aria-label="Scattered requests from email, chat, sheets, phone, notes and tickets pass through ServiceNow and come out as three ordered queues for incidents, requests and cases" role="img" viewBox="0 0 900 350">
<g className="tang"><path d="M70 70L230 140"></path><path d="M200 40L110 170"></path><path d="M110 170L220 260"></path><path d="M230 140L80 280"></path><path d="M70 70L220 260"></path><path d="M200 40L80 280"></path><path d="M110 170L230 140"></path></g>
<g fill="none" stroke="rgba(96,72,240,.35)" strokeWidth="1.6">
<path d="M70 70C190 70 330 170 400 170" id="s1"></path><path d="M200 40C300 40 340 170 400 170" id="s2"></path><path d="M110 170C230 170 330 170 400 170" id="s3"></path><path d="M230 140C310 140 350 170 400 170" id="s4"></path><path d="M80 280C200 280 330 170 400 170" id="s5"></path><path d="M220 260C310 260 350 170 400 170" id="s6"></path>
</g>
<g fill="#6048f0"><circle r="4"><animateMotion dur="3.2s" repeatCount="indefinite"><mpath href="#s1"></mpath></animateMotion></circle><circle r="4"><animateMotion begin="-.8s" dur="2.6s" repeatCount="indefinite"><mpath href="#s2"></mpath></animateMotion></circle><circle r="4"><animateMotion begin="-1.2s" dur="2.4s" repeatCount="indefinite"><mpath href="#s3"></mpath></animateMotion></circle><circle r="4"><animateMotion begin="-.4s" dur="2s" repeatCount="indefinite"><mpath href="#s4"></mpath></animateMotion></circle><circle r="4"><animateMotion begin="-1.6s" dur="3s" repeatCount="indefinite"><mpath href="#s5"></mpath></animateMotion></circle><circle r="4"><animateMotion begin="-1s" dur="2.3s" repeatCount="indefinite"><mpath href="#s6"></mpath></animateMotion></circle></g>
<g fontSize="11" fontWeight="700" stroke="rgba(96,72,240,.4)" strokeWidth="1.4" textAnchor="middle">
<g transform="translate(70 70)"><circle fill="#fff" r="27"></circle><text stroke="none" y="4">Email</text></g>
<g transform="translate(200 40)"><circle fill="#fff" r="27"></circle><text stroke="none" y="4">Chat</text></g>
<g transform="translate(110 170)"><circle fill="#fff" r="27"></circle><text stroke="none" y="4">Sheets</text></g>
<g transform="translate(230 140)"><circle fill="#fff" r="27"></circle><text stroke="none" y="4">Phone</text></g>
<g transform="translate(80 280)"><circle fill="#fff" r="27"></circle><text stroke="none" y="4">Notes</text></g>
<g transform="translate(220 260)"><circle fill="#fff" r="27"></circle><text stroke="none" y="4">Tickets</text></g>
</g>
<defs><linearGradient id="bag" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stopColor="#8d6cff"></stop><stop offset="1" stopColor="#4f9cff"></stop></linearGradient></defs>
<circle cx="450" cy="170" fill="none" r="74" stroke="rgba(96,72,240,.35)" strokeDasharray="4 9"><animateTransform attributeName="transform" dur="20s" from="0 450 170" repeatCount="indefinite" to="360 450 170" type="rotate"></animateTransform></circle>
<rect fill="url(#bag)" height="100" rx="26" width="100" x="400" y="120"></rect><path d="M425 155h50M425 170h50M425 185h30" stroke="#fff" strokeLinecap="round" strokeWidth="4"></path>
<text fontSize="11" fontWeight="700" letterSpacing="1.2" style={{ "fill": "#5a3fe0" }} textAnchor="middle" x="450" y="248">SERVICENOW</text>
<g fill="none" stroke="rgba(13,154,134,.55)" strokeWidth="1.8" strokeLinecap="round"><path d="M500 170C535 170 525 90 556 90" id="o1"></path><path d="M500 170L556 170" id="o2"></path><path d="M500 170C535 170 525 250 556 250" id="o3"></path></g>
<defs><filter id="cardsh" x="-10%" y="-30%" width="120%" height="170%"><feDropShadow dx="0" dy="6" stdDeviation="7" floodColor="#0d9a86" floodOpacity=".16"></feDropShadow></filter></defs>
<g><rect fill="#fff" filter="url(#cardsh)" height="56" rx="16" stroke="rgba(13,154,134,.35)" width="290" x="560" y="62"></rect><rect fill="#0d9a86" height="28" rx="2" width="4" x="560" y="76"></rect><circle cx="592" cy="90" fill="rgba(13,154,134,.12)" r="16"></circle><g transform="translate(592 90)"><path d="M0 -6V1M0 5V5.2" stroke="#0d9a86" strokeWidth="2.4" strokeLinecap="round"></path></g><text fontSize="14" fontWeight="700" style={{ "fill": "#0b5c50" }} x="620" y="87">Incidents</text><text fontSize="11" style={{ "fill": "#4d6f69" }} x="620" y="103">Restored and closed</text><circle cx="822" cy="90" fill="none" r="12" stroke="#0d9a86"><animate attributeName="r" begin="0.0s" dur="2.4s" from="12" repeatCount="indefinite" to="20"></animate><animate attributeName="opacity" begin="0.0s" dur="2.4s" from=".6" repeatCount="indefinite" to="0"></animate></circle><circle cx="822" cy="90" fill="#0d9a86" r="12"></circle><path d="M816.5 90l4 4 7-8" fill="none" stroke="#fff" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.4"></path></g>
<g><rect fill="#fff" filter="url(#cardsh)" height="56" rx="16" stroke="rgba(13,154,134,.35)" width="290" x="560" y="142"></rect><rect fill="#0d9a86" height="28" rx="2" width="4" x="560" y="156"></rect><circle cx="592" cy="170" fill="rgba(13,154,134,.12)" r="16"></circle><g transform="translate(592 170)"><path d="M-5 -4h10M-5 0h10M-5 4h6" stroke="#0d9a86" strokeWidth="2" strokeLinecap="round"></path></g><text fontSize="14" fontWeight="700" style={{ "fill": "#0b5c50" }} x="620" y="167">Requests</text><text fontSize="11" style={{ "fill": "#4d6f69" }} x="620" y="183">Fulfilled on time</text><circle cx="822" cy="170" fill="none" r="12" stroke="#0d9a86"><animate attributeName="r" begin="0.5s" dur="2.4s" from="12" repeatCount="indefinite" to="20"></animate><animate attributeName="opacity" begin="0.5s" dur="2.4s" from=".6" repeatCount="indefinite" to="0"></animate></circle><circle cx="822" cy="170" fill="#0d9a86" r="12"></circle><path d="M816.5 170l4 4 7-8" fill="none" stroke="#fff" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.4"></path></g>
<g><rect fill="#fff" filter="url(#cardsh)" height="56" rx="16" stroke="rgba(13,154,134,.35)" width="290" x="560" y="222"></rect><rect fill="#0d9a86" height="28" rx="2" width="4" x="560" y="236"></rect><circle cx="592" cy="250" fill="rgba(13,154,134,.12)" r="16"></circle><g transform="translate(592 250)"><rect x="-6" y="-5" width="12" height="10" rx="2.5" fill="none" stroke="#0d9a86" strokeWidth="2"></rect></g><text fontSize="14" fontWeight="700" style={{ "fill": "#0b5c50" }} x="620" y="247">Cases</text><text fontSize="11" style={{ "fill": "#4d6f69" }} x="620" y="263">Resolved with context</text><circle cx="822" cy="250" fill="none" r="12" stroke="#0d9a86"><animate attributeName="r" begin="1.0s" dur="2.4s" from="12" repeatCount="indefinite" to="20"></animate><animate attributeName="opacity" begin="1.0s" dur="2.4s" from=".6" repeatCount="indefinite" to="0"></animate></circle><circle cx="822" cy="250" fill="#0d9a86" r="12"></circle><path d="M816.5 250l4 4 7-8" fill="none" stroke="#fff" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.4"></path></g>
<g fill="#0d9a86"><circle r="5"><animateMotion dur="2.8s" repeatCount="indefinite"><mpath href="#o1"></mpath></animateMotion><animate attributeName="opacity" dur="2.8s" keyTimes="0;.1;.85;1" repeatCount="indefinite" values="0;1;1;0"></animate></circle><circle r="5"><animateMotion begin="-.9s" dur="2.4s" repeatCount="indefinite"><mpath href="#o2"></mpath></animateMotion><animate attributeName="opacity" begin="-.9s" dur="2.4s" keyTimes="0;.1;.85;1" repeatCount="indefinite" values="0;1;1;0"></animate></circle><circle r="5"><animateMotion begin="-1.5s" dur="3.1s" repeatCount="indefinite"><mpath href="#o3"></mpath></animateMotion><animate attributeName="opacity" begin="-1.5s" dur="3.1s" keyTimes="0;.1;.85;1" repeatCount="indefinite" values="0;1;1;0"></animate></circle></g>
<text className="cap" textAnchor="middle" x="145" y="332">BEFORE · SCATTERED</text><text className="cap" textAnchor="middle" x="705" y="332">AFTER · ONE QUEUE</text>
</svg>
</div>
<div className="ba-legend"><span><i></i>Requests arrive from every channel</span><span><i></i>Routed, tracked and resolved in one place</span></div>
</div></section><section id="architecture" style={{ "paddingTop": "0" }}><div className="w">
<div className="dh rv"><p className="kick">Platform view</p><h2>One platform, four layers working together</h2><p className="lead">Hover the stack or the list to see how each layer connects people, workflows, data and your existing tools.</p></div>
<PlatformLayers />
</div></section>    </>
  );
}
